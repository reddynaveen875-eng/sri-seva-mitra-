package com.srisevamitra.assistant

import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest
import android.app.assist.AssistStructure
import android.view.View
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.RemoteViews

/**
 * Autofill provider: offers one "Fill details" suggestion that fills the plain text boxes
 * (email, city, state, country, pincode and each pilgrim's name, age and ID number).
 * Dropdowns, dates and buttons are handled by the accessibility engine / floating button.
 */
class SevaAutofillService : AutofillService() {

    private class Field(val id: AutofillId, val sig: String)

    override fun onFillRequest(request: FillRequest, signal: CancellationSignal, callback: FillCallback) {
        val structure = request.fillContexts.lastOrNull()?.structure
        if (structure == null) {
            callback.onSuccess(null)
            return
        }
        val fields = ArrayList<Field>()
        for (i in 0 until structure.windowNodeCount) collect(structure.getWindowNodeAt(i).rootViewNode, fields)

        val cfg = Prefs(this).load()
        val pilgrims = cfg.activePilgrims
        val seen = HashMap<String, Int>()
        val ds = RemoteViews(packageName, android.R.layout.simple_list_item_1)
        ds.setTextViewText(android.R.id.text1, "Fill details (Sri Seva Mitra)")
        val builder = Dataset.Builder(ds)
        var count = 0

        fun put(f: Field, v: String) {
            if (v.isBlank()) return
            builder.setValue(f.id, AutofillValue.forText(v))
            count++
        }

        for (f in fields) {
            val s = f.sig
            when {
                Regex("id ?(no|num)|photo ?id.*(no|num)|proof ?(no|num)").containsMatchIn(s) -> {
                    val k = seen.getOrDefault("id", 0); seen["id"] = k + 1
                    pilgrims.getOrNull(k)?.let { put(f, it.idNumber) }
                }
                s.contains("mail") -> put(f, cfg.email)
                s.contains("pin") || s.contains("zip") || s.contains("postal") -> put(f, cfg.pincode)
                s.contains("city") || s.contains("town") -> put(f, cfg.city)
                s.contains("state") -> put(f, cfg.state)
                s.contains("country") -> put(f, cfg.country)
                Regex("(^|[^a-z])age([^a-z]|$)").containsMatchIn(s) -> {
                    val k = seen.getOrDefault("age", 0); seen["age"] = k + 1
                    pilgrims.getOrNull(k)?.let { put(f, it.age) }
                }
                s.contains("name") && !s.contains("user") -> {
                    val k = seen.getOrDefault("name", 0); seen["name"] = k + 1
                    pilgrims.getOrNull(k)?.let { put(f, it.name) }
                }
            }
        }

        if (count == 0) {
            callback.onSuccess(null)
            return
        }
        callback.onSuccess(FillResponse.Builder().addDataset(builder.build()).build())
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        callback.onSuccess()
    }

    private fun collect(node: AssistStructure.ViewNode, out: MutableList<Field>) {
        val id = node.autofillId
        if (id != null && node.autofillType == View.AUTOFILL_TYPE_TEXT) {
            val parts = ArrayList<String>()
            node.idEntry?.let { parts.add(it) }
            node.hint?.let { parts.add(it) }
            node.contentDescription?.let { parts.add(it.toString()) }
            node.autofillHints?.forEach { parts.add(it) }
            node.htmlInfo?.attributes?.forEach { a ->
                if (a.first in setOf("name", "id", "placeholder", "aria-label", "autocomplete")) parts.add(a.second)
            }
            val sig = parts.joinToString(" ").lowercase()
            if (sig.isNotBlank()) out.add(Field(id, sig))
        }
        for (i in 0 until node.childCount) collect(node.getChildAt(i), out)
    }
}
