package com.srisevamitra.assistant

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

/** Quick Settings tile "Seva Fill": one-tap ON/OFF for the floating button. */
class SevaTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        if (FloatingBubbleService.running) {
            startService(Intent(this, FloatingBubbleService::class.java).setAction(FloatingBubbleService.ACTION_STOP))
            FloatingBubbleService.running = false
        } else if (!Settings.canDrawOverlays(this)) {
            openApp()
            return
        } else {
            ContextCompat.startForegroundService(this, Intent(this, FloatingBubbleService::class.java))
            FloatingBubbleService.running = true
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (FloatingBubbleService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
