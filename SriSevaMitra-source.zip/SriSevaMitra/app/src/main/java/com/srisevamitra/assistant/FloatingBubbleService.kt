package com.srisevamitra.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/**
 * Draggable Lakshmi bubble drawn over other apps. Tap it to open the action panel.
 * Runs as a foreground service so Android keeps it alive.
 */
class FloatingBubbleService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var bubble: ImageView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) showBubble()
        running = true
        Toast.makeText(this, "Floating button started. Open the TTD form.", Toast.LENGTH_SHORT).show()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { /* ignore */ } }
        bubble = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ foreground notification

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingBubbleService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Sri Seva Mitra floating button is on")
            .setContentText("Tap the bubble over the TTD page. Tap here to open the app.")
            .setContentIntent(open)
            .addAction(0, "Turn off", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 4202, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    // ------------------------------------------------------------------ bubble

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun newParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun showBubble() {
        val view = ImageView(this)
        view.setImageResource(R.drawable.ic_bubble)
        view.layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        val p = newParams()
        p.width = dp(64)
        p.height = dp(64)
        p.x = 0
        p.y = dp(200)
        bubbleParams = p

        view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = bubbleParams ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(v, lp)
                            if (panel != null) hidePanel()
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })
        bubble = view
        wm.addView(view, p)
    }

    // ------------------------------------------------------------------ panel

    private fun togglePanel() {
        if (panel != null) hidePanel() else showPanel()
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { /* ignore */ } }
        panel = null
    }

    private fun panelButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 13f
        b.setOnClickListener { onClick() }
        return b
    }

    private fun showPanel() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(10), dp(8), dp(10), dp(8))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#FFF8E1"))
        bg.setStroke(dp(2), Color.parseColor("#FFC107"))
        bg.cornerRadius = dp(14).toFloat()
        box.background = bg

        val title = TextView(this)
        title.text = "Sri Seva Mitra"
        title.textSize = 15f
        title.setTextColor(Color.parseColor("#7B1230"))
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        box.addView(title)

        val status = TextView(this)
        status.text = prefs.lastStatus.ifEmpty { "Ready" }
        status.textSize = 11f
        status.setTextColor(Color.DKGRAY)
        box.addView(status)

        box.addView(panelButton("Start full booking") { go(RunMode.FULL) })
        box.addView(panelButton("Fill form only") { go(RunMode.FORM_ONLY) })
        box.addView(panelButton("Fill remaining IDs only") { go(RunMode.IDS_ONLY) })
        box.addView(panelButton("Scan form (15 s)") { go(RunMode.SCAN) })
        box.addView(panelButton("Stop") {
            prefs.armed = false
            BookingAutomationService.instance?.cancel()
            toast("Stopped")
            hidePanel()
        })
        box.addView(panelButton("Open app") {
            hidePanel()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        box.addView(panelButton("Close floating button") { stopSelf() })

        val bp = bubbleParams
        val p = newParams()
        p.width = dp(230)
        p.x = (bp?.x ?: 0) + dp(70)
        p.y = (bp?.y ?: 0)
        val screenW = resources.displayMetrics.widthPixels
        if (p.x + dp(230) > screenW) p.x = maxOf(0, (bp?.x ?: 0) - dp(236))
        panel = box
        wm.addView(box, p)
    }

    private fun go(mode: RunMode) {
        val svc = BookingAutomationService.instance
        val err = if (svc == null) {
            "Accessibility is OFF - turn it on in Accessibility settings"
        } else {
            svc.startRun(mode)
        }
        hidePanel()
        toast(err ?: "Started: $mode")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val CHANNEL = "seva_bubble"
        const val ACTION_STOP = "com.srisevamitra.assistant.STOP_BUBBLE"

        @Volatile
        var running = false
    }
}
