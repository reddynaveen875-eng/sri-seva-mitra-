package com.srisevamitra.assistant

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Accessibility engine. A run starts either (a) automatically, when the app is "armed" and the
 * target app shows up, or (b) on demand from the floating button via [startRun].
 */
class BookingAutomationService : AccessibilityService() {

    private val running = AtomicBoolean(false)

    @Volatile
    private var cancelled = false
    private var worker: Thread? = null
    private lateinit var prefs: Prefs

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        prefs = Prefs(this)
        Log.d(StateMachine.TAG, "Accessibility service connected")
    }

    private fun accepts(pkg: String): Boolean {
        if (pkg == packageName || pkg == "com.android.systemui") return false
        val target = prefs.targetPackage.trim()
        if (target.isEmpty() || pkg == target) return true
        return target == "com.android.chrome" && pkg in CHROME_VARIANTS
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (!prefs.armed || running.get() || !accepts(pkg)) return

        val cfg = prefs.load()
        val problem = Prefs.validate(cfg)
        if (problem != null) {
            prefs.armed = false
            prefs.lastStatus = "Not started: $problem"
            Notifier.post(this, "Sri Seva Mitra - not started", problem)
            return
        }
        prefs.armed = false // single shot: re-arm for the next attempt
        launch(cfg, pkg, RunMode.FULL)
    }

    /** Called from the floating button. Returns an error message, or null when the run started. */
    fun startRun(mode: RunMode): String? {
        if (running.get()) return "Already running - tap Stop first"
        val cfg = prefs.load()
        val problem = Prefs.validate(cfg, needCalendar = mode == RunMode.FULL)
        if (problem != null && mode != RunMode.SCAN) return problem
        val pkg = rootInActiveWindow?.packageName?.toString()
        if (pkg == null || !accepts(pkg)) return "Open the TTD page first, then tap the button"
        prefs.armed = false
        launch(cfg, pkg, mode)
        return null
    }

    private fun launch(cfg: Config, pkg: String, mode: RunMode) {
        if (!running.compareAndSet(false, true)) return
        cancelled = false
        prefs.lastStatus = "Running ($mode)..."
        val finder = NodeFinder(this).also { it.pkg = pkg }
        Log.d(StateMachine.TAG, "Starting $mode on '$pkg'")
        worker = Thread({
            try {
                StateMachine(applicationContext, finder, cfg, mode) { cancelled }.run()
            } finally {
                running.set(false)
            }
        }, "seva-worker").also { it.start() }
    }

    fun cancel() {
        cancelled = true
        worker?.interrupt()
    }

    fun isRunning(): Boolean = running.get()

    override fun onInterrupt() {
        cancel()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cancel()
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var instance: BookingAutomationService? = null

        private val CHROME_VARIANTS = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary"
        )
    }
}
