package com.srisevamitra.assistant

import android.content.Context
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

enum class State {
    WAIT_FOR_CALENDAR,
    SELECT_SLOT_CARD,
    SET_PERSON_COUNT,
    CLICK_FIRST_CONTINUE,
    FILL_PILGRIM_FORM,
    CLICK_SECOND_CONTINUE,
    REVIEW_AND_FINAL_CLICK,
    DONE
}

/** What a run should do. FULL = the whole booking flow; the others work on the screen that is open right now. */
enum class RunMode { FULL, FORM_ONLY, IDS_ONLY, SCAN }

/** Thrown to stop the run. [isError] = false for a deliberate, successful stop (review page ready). */
class Halt(val state: State, val reason: String, val isError: Boolean = true) : RuntimeException(reason)

/** Label patterns (compared against norm()-ed text, hint, description or view id). */
private object Patterns {
    val NAME = Regex("(pilgrim )?(full )?name")
    val AGE = Regex("age")
    val GENDER = Regex("gender|select gender")
    val ID_TYPE = Regex("id type|id proof type|id proof|photo id proof|proof type|select id type|photo id type")
    val ID_NUMBER = Regex("id number|id no|id proof number|id proof no|photo id number")
    val EMAIL = Regex("e-?mail( id| address)?")
    val CITY = Regex("city|town|city ?/ ?town")
    val STATE = Regex("state|select state")
    val COUNTRY = Regex("country|select country")
    val PINCODE = Regex("pin ?code|zip ?code|postal code|pin")
    val PERSONS = Regex("(number of persons|number of tickets|no\\.? of tickets|no\\.? of persons)( ?:? ?\\d+)?")
    val AVAILABLE = Regex("(\\d+)\\s*available", RegexOption.IGNORE_CASE)
    val DIGITS = Regex("\\d+")
    val DAY = Regex("\\d{1,2}")
}

private enum class Kind(val re: Regex, val mode: NodeFinder.Mode) {
    NAME(Patterns.NAME, NodeFinder.Mode.EDITABLE),
    AGE(Patterns.AGE, NodeFinder.Mode.EDITABLE),
    GENDER(Patterns.GENDER, NodeFinder.Mode.DROPDOWN),
    ID_TYPE(Patterns.ID_TYPE, NodeFinder.Mode.DROPDOWN),
    ID_NUMBER(Patterns.ID_NUMBER, NodeFinder.Mode.EDITABLE)
}

/**
 * The whole booking flow, run on a worker thread. Each state either completes or throws [Halt].
 * It never interacts with payment, CAPTCHA or OTP screens.
 */
class StateMachine(
    private val ctx: Context,
    private val finder: NodeFinder,
    private val cfg: Config,
    private val mode: RunMode,
    private val isCancelled: () -> Boolean
) {
    private val t0 = SystemClock.elapsedRealtime()
    private val budgetMs = TOTAL_MS + cfg.waitSeconds * 1000L

    @Volatile
    private var current = State.WAIT_FOR_CALENDAR
    private var watchBlocked = false
    private var captchaLogged = false

    private val cache = HashMap<Kind, List<AccessibilityNodeInfo>>()
    private val sizes = HashMap<Kind, Int>()

    // ------------------------------------------------------------------ plumbing

    private fun elapsed(): Long = SystemClock.elapsedRealtime() - t0

    private fun log(msg: String) {
        Log.d(TAG, "[${elapsed()}ms] $msg")
    }

    private fun enter(s: State) {
        current = s
        log("=== $s ===")
    }

    private fun fail(reason: String): Nothing = throw Halt(current, reason)

    private fun guard() {
        if (isCancelled()) throw Halt(current, "stopped by user")
        if (elapsed() > budgetMs) throw Halt(current, "time limit reached")
    }

    private fun pause(ms: Long) {
        var left = ms
        while (left > 0) {
            val step = minOf(left, 50L)
            Thread.sleep(step)
            left -= step
            guard()
        }
    }

    private fun <T : Any> pollUntil(
        timeoutMs: Long,
        intervalMs: Long,
        fn: (List<AccessibilityNodeInfo>) -> T?
    ): T? {
        val end = elapsed() + timeoutMs
        while (true) {
            guard()
            val all = finder.snapshot()
            if (all.isNotEmpty()) checkSafety(all)
            val r = fn(all)
            if (r != null) return r
            if (elapsed() >= end) return null
            Thread.sleep(intervalMs)
        }
    }

    private fun containsText(all: List<AccessibilityNodeInfo>, needle: String): Boolean =
        all.any { finder.label(it).lowercase().contains(needle) }

    /** Stops on payment pages; notes (but never touches) CAPTCHA / OTP elements. */
    private fun checkSafety(all: List<AccessibilityNodeInfo>) {
        for (n in all) {
            val s = finder.label(n).lowercase()
            if (s.isEmpty()) continue
            if (PAYMENT_KEYS.any { s.contains(it) }) {
                throw Halt(current, "Payment page detected - stopped. Complete payment yourself.")
            }
            if (watchBlocked && s.contains("already blocked by other pilgrim")) {
                throw Halt(current, "Slot is already blocked by another pilgrim - stopped.")
            }
            if (!captchaLogged && (s.contains("captcha") || s.contains("enter otp"))) {
                captchaLogged = true
                log("CAPTCHA/OTP element visible - automation will not touch it")
            }
        }
    }

    // ------------------------------------------------------------------ entry point

    fun run() {
        val prefs = Prefs(ctx)
        try {
            log("Run started: seva='${cfg.seva}' month='${cfg.month}' day=${cfg.day} persons=${cfg.persons} autoConfirm=${cfg.autoConfirm} wait=${cfg.waitSeconds}s")

            val msg: String
            when (mode) {
                RunMode.FULL -> {
                    enter(State.WAIT_FOR_CALENDAR); waitForCalendar()
                    watchBlocked = true
                    enter(State.SELECT_SLOT_CARD); selectSlotCard()
                    enter(State.SET_PERSON_COUNT); setPersonCount()
                    enter(State.CLICK_FIRST_CONTINUE); clickFirstContinue()
                    enter(State.FILL_PILGRIM_FORM); fillPilgrimForm()
                    enter(State.CLICK_SECOND_CONTINUE); clickSecondContinue()
                    enter(State.REVIEW_AND_FINAL_CLICK); reviewAndFinalClick()
                    msg = "Booking flow finished in %.1f s".format(elapsed() / 1000.0)
                }
                RunMode.FORM_ONLY -> {
                    watchBlocked = true
                    enter(State.FILL_PILGRIM_FORM); fillPilgrimForm()
                    msg = "Form filled in %.1f s - check it, then press Continue yourself.".format(elapsed() / 1000.0)
                }
                RunMode.IDS_ONLY -> {
                    enter(State.FILL_PILGRIM_FORM); fillIdsOnly()
                    msg = "ID type and ID numbers filled in %.1f s.".format(elapsed() / 1000.0)
                }
                RunMode.SCAN -> {
                    scanForm()
                    msg = "Scan saved. Open the app to copy the report."
                }
            }

            enter(State.DONE)
            log(msg)
            prefs.lastStatus = "DONE - $msg"
            Notifier.post(ctx, "Sri Seva Mitra - success", msg)
        } catch (h: Halt) {
            val title = if (h.isError) "Sri Seva Mitra - ${h.state} failed" else "Sri Seva Mitra - review page ready"
            log("HALT in ${h.state}: ${h.reason}")
            prefs.lastStatus = "${h.state}: ${h.reason}"
            Notifier.post(ctx, title, h.reason)
        } catch (e: InterruptedException) {
            log("Interrupted")
            prefs.lastStatus = "$current: stopped by user"
        } catch (e: Exception) {
            log("Unexpected error in $current: $e")
            prefs.lastStatus = "$current: unexpected error ${e.javaClass.simpleName}"
            Notifier.post(ctx, "Sri Seva Mitra - $current failed", "Unexpected error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ STATE 1

    private fun dayValue(n: AccessibilityNodeInfo): Int? {
        val s = finder.label(n)
        if (!Patterns.DAY.matches(s)) return null
        val v = s.toInt()
        return if (v in 1..31) v else null
    }

    private fun findDayContainer(heading: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var p: AccessibilityNodeInfo? = heading.parent
        var depth = 0
        while (p != null && depth < 12) {
            if (finder.subtree(p).count { dayValue(it) != null } >= 20) return p
            p = p.parent
            depth++
        }
        return null
    }

    private fun waitForCalendar() {
        val monthNorm = norm(cfg.month)
        var lastLog = -5000L
        val cell = pollUntil(cfg.waitSeconds * 1000L, 300) { all ->
            val heading = all.firstOrNull { norm(finder.label(it)) == monthNorm }
            var found: AccessibilityNodeInfo? = null
            if (heading != null) {
                val container = findDayContainer(heading)
                if (container != null) {
                    found = finder.subtree(container).firstOrNull {
                        dayValue(it) == cfg.day && it.isEnabled && finder.isVisible(it)
                    }
                }
            }
            if (found == null && elapsed() - lastLog >= 5000) {
                lastLog = elapsed()
                log("Waiting for '${cfg.month}' day ${cfg.day} (heading ${if (heading != null) "seen" else "not seen"})")
            }
            found
        } ?: fail("Date cell not found - check month text")

        finder.showOnScreen(cell)
        if (!finder.click(cell)) fail("Could not click date cell ${cfg.day}")
        log("Date clicked: ${cfg.month} ${cfg.day}")
    }

    // ------------------------------------------------------------------ STATE 2

    private fun findSlotCard(all: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? {
        for (n in all) {
            val m = Patterns.AVAILABLE.find(finder.label(n)) ?: continue
            val count = m.groupValues[1].toIntOrNull() ?: continue
            if (count <= 0) continue
            val target = finder.clickableAncestor(n) ?: n
            if (!n.isEnabled || !target.isEnabled) continue
            return n
        }
        return null
    }

    private fun selectSlotCard() {
        val card = pollUntil(SLOT_WAIT_MS, 250) { all -> findSlotCard(all) }
            ?: fail("No slot card with availability above 0 found within ${SLOT_WAIT_MS / 1000}s")
        finder.showOnScreen(card)
        finder.click(card)
        log("Slot card clicked: '${finder.label(card)}'")
        pause(700)

        var all = finder.snapshot()
        checkSafety(all)
        if (containsText(all, "please select an available slot")) {
            log("'Please select an available slot' shown - retrying click once")
            pause(300)
            val again = findSlotCard(all) ?: fail("Slot card disappeared before retry")
            finder.showOnScreen(again)
            finder.click(again)
            pause(700)
            all = finder.snapshot()
            checkSafety(all)
            if (containsText(all, "please select an available slot")) {
                fail("'Please select an available slot' still shown after retry")
            }
        }
        log("Slot selected")
    }

    // ------------------------------------------------------------------ STATE 3

    private fun setPersonCount() {
        val labelNode = pollUntil(5000, 200) { all ->
            all.firstOrNull { n ->
                val s = norm(finder.label(n))
                s.length <= 40 && Patterns.PERSONS.matches(s)
            }
        }
        if (labelNode == null) {
            log("Number of Persons field not found - continuing")
            return
        }
        val all = finder.snapshot()
        val control = finder.controls(all, Patterns.PERSONS, NodeFinder.Mode.ANY).firstOrNull() ?: labelNode
        val curTxt = finder.label(control).ifEmpty { finder.label(labelNode) }
        val cur = Patterns.DIGITS.find(curTxt)?.value?.toIntOrNull()
        log("Number of persons currently=${cur ?: "unknown"}, wanted=${cfg.persons}")

        if (cur == cfg.persons) return
        if (!control.isEnabled) {
            log("Number of persons field is disabled/locked - continuing")
            return
        }

        if (finder.isEditable(control)) {
            if (!typeInto(control, cfg.persons.toString())) fail("Could not set number of persons")
        } else {
            val want = Regex("0*${cfg.persons}( .*)?")
            val ok = pickOption(control, { s -> want.matches(s) }, allowRelax = false)
            if (!ok) fail("Option '${cfg.persons}' not found in Number of Persons dropdown")
        }
        pause(500)
        log("Number of persons set to ${cfg.persons}")
    }

    // ------------------------------------------------------------------ STATES 4 / 6 / 7 (stable click)

    private fun findButton(all: List<AccessibilityNodeInfo>, labels: List<String>): Pair<String, AccessibilityNodeInfo>? {
        for (lbl in labels) {
            val want = norm(lbl)
            val targets = all.filter { norm(finder.label(it)) == want }
                .map { finder.clickableAncestor(it) ?: it }
            if (targets.isEmpty()) continue
            val pick = targets.firstOrNull { finder.isVisible(it) } ?: targets.first()
            return Pair(lbl, pick)
        }
        return null
    }

    /**
     * Waits until the same enabled + visible button is seen [needStable] polls in a row, then clicks it exactly once.
     * Returns the label that was clicked.
     */
    private fun stableClick(labels: List<String>, timeoutMs: Long, intervalMs: Long, needStable: Int): String {
        var lastNode: AccessibilityNodeInfo? = null
        var lastLabel = ""
        var stable = 0
        var polls = 0
        val end = elapsed() + timeoutMs
        while (true) {
            guard()
            val all = finder.snapshot()
            checkSafety(all)
            val found = findButton(all, labels)
            if (found != null) {
                val (lbl, node) = found
                if (node.isEnabled && finder.isVisible(node)) {
                    stable = if (lastNode != null && lastNode == node && lbl == lastLabel) stable + 1 else 1
                    lastNode = node
                    lastLabel = lbl
                    if (stable >= needStable) {
                        val ok = finder.click(node)
                        log("Clicked '$lbl' (stable=$stable, ok=$ok)")
                        if (!ok) fail("Click on '$lbl' was not accepted")
                        return lbl
                    }
                } else {
                    stable = 0
                    lastNode = null
                    if (!finder.isVisible(node)) finder.showOnScreen(node)
                }
            } else {
                stable = 0
                lastNode = null
                if (polls % 10 == 9) finder.scrollForward(all)
            }
            polls++
            if (elapsed() >= end) {
                fail("Button ${labels.joinToString("/") { "'$it'" }} not enabled and visible in time")
            }
            Thread.sleep(intervalMs)
        }
    }

    private fun clickFirstContinue() {
        stableClick(listOf("Continue"), CONTINUE_WAIT_MS, 100, 3)
        val seen = pollUntil(FORM_WAIT_MS, 250) { all ->
            val hasName = all.any { finder.matches(it, Patterns.NAME) }
            val hasAge = all.any { finder.matches(it, Patterns.AGE) }
            val hasId = all.any { finder.matches(it, Patterns.ID_NUMBER) }
            if (hasName && hasAge && hasId) true else null
        }
        if (seen == null) fail("Pilgrim form did not appear within ${FORM_WAIT_MS / 1000}s")
        log("Pilgrim form detected")
    }

    // ------------------------------------------------------------------ STATE 5

    /** Types [value] into an editable node and verifies it. */
    private fun typeInto(node: AccessibilityNodeInfo, value: String): Boolean {
        finder.showOnScreen(node)
        pause(80)
        for (attempt in 1..2) {
            finder.setText(node, value)
            pause(150)
            val now = finder.currentText(node)
            if (compact(now) == compact(value)) return true
            finder.click(node)
            pause(150)
        }
        val now = finder.currentText(node)
        if (now.isNotEmpty()) {
            log("Value could not be verified (field shows '${now.take(12)}...') - treating as set")
            return true
        }
        return false
    }

    private fun compact(s: String): String = s.filter { it.isLetterOrDigit() }.lowercase()

    /** Opens a dropdown and clicks the option accepted by [accept] (receives norm()-ed option text). */
    private fun pickOption(control: AccessibilityNodeInfo, accept: (String) -> Boolean, allowRelax: Boolean): Boolean {
        if (accept(norm(finder.label(control)))) return true // already selected

        val before = HashSet<AccessibilityNodeInfo>(finder.snapshot())
        finder.showOnScreen(control)
        pause(150)
        finder.click(control)

        val start = elapsed()
        var deadline = start + OPTION_WAIT_MS
        var scrolls = 0
        while (true) {
            guard()
            val all = finder.snapshot()
            checkSafety(all)
            val relaxed = allowRelax && elapsed() - start > 2000
            val cand = all.firstOrNull { n ->
                n != control &&
                    finder.label(n).isNotEmpty() &&
                    accept(norm(finder.label(n))) &&
                    (!before.contains(n) || (relaxed && finder.isVisible(n)))
            }
            if (cand != null) {
                val ok = finder.click(cand)
                log("Option clicked: '${finder.label(cand)}' ok=$ok")
                pause(300)
                return ok
            }
            if (elapsed() >= deadline) {
                if (scrolls >= 5) return false
                finder.scrollForward(all)
                scrolls++
                deadline = elapsed() + 700
            }
            Thread.sleep(120)
        }
    }

    private fun control(kind: Kind, i: Int): AccessibilityNodeInfo? {
        val deadline = elapsed() + 4000
        while (true) {
            guard()
            val cached = cache[kind]?.getOrNull(i)
            if (cached != null && cached.refresh()) return cached
            val all = finder.snapshot()
            checkSafety(all)
            val fresh = finder.controls(all, kind.re, kind.mode)
            if (fresh.size > i && fresh.size >= (sizes[kind] ?: 0)) {
                cache[kind] = fresh
                if (sizes[kind] == null) sizes[kind] = fresh.size
                return fresh[i]
            }
            if (elapsed() >= deadline) return null
            Thread.sleep(150)
        }
    }

    private fun waitEnabled(kind: Kind, i: Int, timeoutMs: Long): AccessibilityNodeInfo? {
        val end = elapsed() + timeoutMs
        while (true) {
            guard()
            val n = control(kind, i)
            if (n != null) {
                n.refresh()
                if (n.isEnabled) return n
            }
            if (elapsed() >= end) return null
            Thread.sleep(150)
        }
    }

    private fun fillGeneral(name: String, re: Regex, value: String, failures: MutableList<String>) {
        if (value.isBlank()) return
        val node = pollUntil(3000, 150) { all ->
            finder.controls(all, re, NodeFinder.Mode.ANY).firstOrNull()
        }
        if (node == null) {
            log("$name field not found - skipped")
            return
        }
        val ok = if (finder.isEditable(node)) {
            typeInto(node, value)
        } else {
            val want = norm(value)
            pickOption(node, { s -> s == want }, allowRelax = true) ||
                pickOption(node, { s -> s.contains(want) }, allowRelax = true)
        }
        log("$name: ${if (ok) "OK" else "FAILED"}")
        if (!ok) failures.add(name)
    }

    private fun fillPilgrimForm() {
        val failures = ArrayList<String>()
        val rows = cfg.activePilgrims

        rows.forEachIndexed { i, p ->
            val report = StringBuilder()
            fun step(what: String, ok: Boolean) {
                if (report.isNotEmpty()) report.append(", ")
                report.append("$what ${if (ok) "OK" else "FAILED"}")
                if (!ok) failures.add("row ${i + 1} $what")
            }

            step("name", control(Kind.NAME, i)?.let { typeInto(it, p.name) } ?: false)
            step("age", control(Kind.AGE, i)?.let { typeInto(it, p.age) } ?: false)

            val g = norm(p.gender)
            step("gender", control(Kind.GENDER, i)?.let { pickOption(it, { s -> s == g }, allowRelax = true) } ?: false)

            val idt = norm(p.idType)
            val idAccept: (String) -> Boolean = if (idt.startsWith("pass")) {
                { s -> s.contains("passport") }
            } else {
                { s -> s.contains("aadhaar") || s.contains("aadhar") }
            }
            step("idType", control(Kind.ID_TYPE, i)?.let { pickOption(it, idAccept, allowRelax = true) } ?: false)

            val idNode = waitEnabled(Kind.ID_NUMBER, i, 5000)
            if (idNode == null) log("Row ${i + 1}: ID Number field did not become enabled")
            step("idNumber", idNode?.let { typeInto(it, p.idNumber) } ?: false)

            log("Row ${i + 1} (${p.name}): $report")
        }

        fillGeneral("Email", Patterns.EMAIL, cfg.email, failures)
        fillGeneral("City", Patterns.CITY, cfg.city, failures)
        fillGeneral("State", Patterns.STATE, cfg.state, failures)
        fillGeneral("Country", Patterns.COUNTRY, cfg.country, failures)
        fillGeneral("Pincode", Patterns.PINCODE, cfg.pincode, failures)

        if (failures.isNotEmpty()) fail("Pilgrim form incomplete: ${failures.joinToString(", ")}")
    }


    // ------------------------------------------------------------------ extra modes

    /** "Fill remaining IDs": only the ID type and ID number of each pilgrim row. */
    private fun fillIdsOnly() {
        val failures = ArrayList<String>()
        cfg.activePilgrims.forEachIndexed { i, p ->
            val idt = norm(p.idType)
            val accept: (String) -> Boolean = if (idt.startsWith("pass")) {
                { s -> s.contains("passport") }
            } else {
                { s -> s.contains("aadhaar") || s.contains("aadhar") }
            }
            val typeOk = control(Kind.ID_TYPE, i)?.let { pickOption(it, accept, allowRelax = true) } ?: false
            val idNode = waitEnabled(Kind.ID_NUMBER, i, 5000)
            val numOk = idNode?.let { typeInto(it, p.idNumber) } ?: false
            log("Row ${i + 1} (${p.name}): idType ${if (typeOk) "OK" else "FAILED"}, idNumber ${if (numOk) "OK" else "FAILED"}")
            if (!typeOk) failures.add("row ${i + 1} idType")
            if (!numOk) failures.add("row ${i + 1} idNumber")
        }
        if (failures.isNotEmpty()) fail("ID fill incomplete: ${failures.joinToString(", ")}")
    }

    /** Records every node seen on screen for 15 s (menus included) so the layout can be checked. */
    private fun scanForm() {
        val lines = LinkedHashSet<String>()
        val end = elapsed() + SCAN_MS
        var total = 0
        while (elapsed() < end) {
            guard()
            val all = finder.snapshot()
            total = maxOf(total, all.size)
            for (n in all) {
                if (lines.size >= 3000) break
                val r = android.graphics.Rect()
                n.getBoundsInScreen(r)
                lines.add(
                    "${(n.className ?: "?").toString().substringAfterLast('.')} " +
                        "text='${finder.textOf(n).take(60)}' desc='${finder.descOf(n).take(60)}' " +
                        "hint='${finder.hintOf(n).take(40)}' id='${finder.idOf(n)}' " +
                        "click=${n.isClickable} edit=${finder.isEditable(n)} enabled=${n.isEnabled} " +
                        "visible=${n.isVisibleToUser} bounds=$r"
                )
            }
            Thread.sleep(1000)
        }
        val report = StringBuilder()
        report.append("Sri Seva Mitra scan: ${lines.size} unique nodes, max nodes on one screen=$total\n")
        for (l in lines) report.append(l).append('\n')
        ctx.openFileOutput(REPORT_FILE, Context.MODE_PRIVATE).use { it.write(report.toString().toByteArray()) }
        log("Scan report saved (${lines.size} lines)")
    }

    // ------------------------------------------------------------------ STATE 6

    private fun clickSecondContinue() {
        stableClick(listOf("Continue"), CONTINUE_WAIT_MS, 100, 3)
        val seen = pollUntil(REVIEW_WAIT_MS, 200) { all ->
            val heading = containsText(all, "pilgrim details")
            val formStillThere = all.any { finder.matches(it, Patterns.NAME) && finder.isEditable(it) && finder.isVisible(it) }
            if (heading && !formStillThere) true else null
        }
        if (seen == null) {
            fail("Review page ('Pilgrim Details') not detected within ${REVIEW_WAIT_MS / 1000}s - check the form for validation errors")
        }
        log("Review page detected")
    }

    // ------------------------------------------------------------------ STATE 7

    private fun signature(all: List<AccessibilityNodeInfo>): Int {
        var h = all.size
        for (n in all) if (finder.isVisible(n)) h = h * 31 + finder.label(n).hashCode()
        return h
    }

    private fun scrollToBottom() {
        var lastSig = 0
        var same = 0
        for (i in 1..30) {
            guard()
            val all = finder.snapshot()
            checkSafety(all)
            val moved = finder.scrollForward(all) || finder.swipeUp()
            pause(250)
            val sig = signature(finder.snapshot())
            if (!moved || sig == lastSig) same++ else same = 0
            lastSig = sig
            if (same >= 2) break
        }
        log("Scrolled to bottom")
    }

    private fun reviewAndFinalClick() {
        scrollToBottom()
        if (!cfg.autoConfirm) {
            throw Halt(current, "Review page ready - press Confirm yourself.", isError = false)
        }
        val clicked = stableClick(FINAL_LABELS, FINAL_WAIT_MS, 50, 3)
        log("Final button '$clicked' clicked once")
    }

    companion object {
        const val TAG = "TTDBooking"
        const val TOTAL_MS = 300_000L
        const val SLOT_WAIT_MS = 8_000L
        const val CONTINUE_WAIT_MS = 5_000L
        const val FORM_WAIT_MS = 10_000L
        const val REVIEW_WAIT_MS = 3_000L
        const val FINAL_WAIT_MS = 3_000L
        const val OPTION_WAIT_MS = 3_000L
        const val SCAN_MS = 15_000L
        const val REPORT_FILE = "scan_report.txt"

        private val FINAL_LABELS = listOf("Confirm", "Book Now", "Pay Now", "Continue")

        private val PAYMENT_KEYS = listOf(
            "payment gateway", "net banking", "netbanking", "debit card", "credit card",
            "razorpay", "billdesk", "payu", "bhim upi"
        )
    }
}
