package com.srisevamitra.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Lower-cases, collapses whitespace and strips trailing "*" / ":" so labels compare cleanly. */
fun norm(s: String): String =
    s.lowercase().replace(Regex("\\s+"), " ").trim().trimEnd('*', ':', ' ')

/**
 * All accessibility-tree reading and acting helpers (find, click, type, scroll).
 * Every method is safe to call from a background worker thread.
 */
class NodeFinder(private val service: AccessibilityService) {

    enum class Mode { EDITABLE, DROPDOWN, ANY }

    /** Package of the browser window we are driving; other windows are ignored. */
    @Volatile
    var pkg: String? = null

    // ------------------------------------------------------------------ tree access

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val wanted = pkg
        fun consider(r: AccessibilityNodeInfo?) {
            if (r == null) return
            if (wanted != null && r.packageName?.toString() != wanted) return
            if (out.none { it == r }) out.add(r)
        }
        try { consider(service.rootInActiveWindow) } catch (e: Exception) { /* ignore */ }
        try { for (w in service.windows) consider(w.root) } catch (e: Exception) { /* ignore */ }
        return out
    }

    /** Depth-first, document-order list of every node in the browser's windows. */
    fun snapshot(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        for (r in roots()) flattenInto(r, out)
        return out
    }

    fun subtree(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        flattenInto(root, out)
        return out
    }

    private fun flattenInto(root: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        val stack = java.util.ArrayDeque<AccessibilityNodeInfo>()
        stack.push(root)
        while (stack.isNotEmpty() && out.size < MAX_NODES) {
            val n = stack.pop()
            out.add(n)
            for (i in n.childCount - 1 downTo 0) {
                val c = n.getChild(i)
                if (c != null) stack.push(c)
            }
        }
    }

    // ------------------------------------------------------------------ text helpers

    fun textOf(n: AccessibilityNodeInfo): String = n.text?.toString()?.trim() ?: ""
    fun descOf(n: AccessibilityNodeInfo): String = n.contentDescription?.toString()?.trim() ?: ""
    fun hintOf(n: AccessibilityNodeInfo): String =
        if (Build.VERSION.SDK_INT >= 26) (n.hintText?.toString()?.trim() ?: "") else ""

    fun idOf(n: AccessibilityNodeInfo): String = n.viewIdResourceName?.substringAfterLast('/') ?: ""

    /** Visible label: text, or content description when there is no text. */
    fun label(n: AccessibilityNodeInfo): String {
        val t = textOf(n)
        return if (t.isNotEmpty()) t else descOf(n)
    }

    private fun ownLabels(n: AccessibilityNodeInfo): List<String> =
        listOf(textOf(n), descOf(n), hintOf(n), idOf(n)).filter { it.isNotEmpty() }.map { norm(it) }

    fun matches(n: AccessibilityNodeInfo, re: Regex): Boolean = ownLabels(n).any { re.matches(it) }

    fun isEditable(n: AccessibilityNodeInfo): Boolean =
        n.isEditable || (n.className?.toString() ?: "").contains("EditText")

    fun isVisible(n: AccessibilityNodeInfo): Boolean {
        if (!n.isVisibleToUser) return false
        val r = Rect()
        n.getBoundsInScreen(r)
        return !r.isEmpty
    }

    fun clickableAncestor(n: AccessibilityNodeInfo, maxDepth: Int = 6): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d <= maxDepth) {
            if (c.isClickable) return c
            c = c.parent
            d++
        }
        return null
    }

    private fun nextMatching(
        all: List<AccessibilityNodeInfo>,
        from: Int,
        window: Int,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        var j = from + 1
        while (j < all.size && j <= from + window) {
            if (pred(all[j])) return all[j]
            j++
        }
        return null
    }

    /**
     * Finds the interactive controls whose label matches [re], in document order.
     * A control is either the node itself (matching text / description / hint) or the
     * first editable / clickable node following a matching label node.
     */
    fun controls(all: List<AccessibilityNodeInfo>, re: Regex, mode: Mode): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun add(n: AccessibilityNodeInfo?) {
            if (n != null && out.none { it == n }) out.add(n)
        }
        for (i in all.indices) {
            val n = all[i]
            if (!matches(n, re)) continue
            val editable = isEditable(n)
            when (mode) {
                Mode.EDITABLE ->
                    if (editable) add(n) else add(nextMatching(all, i, 6) { isEditable(it) })
                Mode.DROPDOWN ->
                    if (!editable) {
                        val anc = clickableAncestor(n, 2)
                        if (anc != null) {
                            add(anc)
                        } else {
                            add(nextMatching(all, i, 8) { it.isClickable && !isEditable(it) } ?: n)
                        }
                    }
                Mode.ANY ->
                    if (editable) {
                        add(n)
                    } else {
                        val anc = clickableAncestor(n, 2)
                        if (anc != null) {
                            add(anc)
                        } else {
                            add(nextMatching(all, i, 8) { it.isClickable || isEditable(it) } ?: n)
                        }
                    }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ actions

    fun showOnScreen(n: AccessibilityNodeInfo) {
        try {
            n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN.id)
        } catch (e: Exception) { /* ignore */ }
    }

    /** ACTION_CLICK on the nearest clickable ancestor, falling back to a tap gesture. */
    fun click(n: AccessibilityNodeInfo): Boolean {
        val target = clickableAncestor(n)
        if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return tap(n)
    }

    fun tap(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return dispatch(GestureDescription.StrokeDescription(path, 0, 60))
    }

    fun swipeUp(): Boolean {
        val m = service.resources.displayMetrics
        val x = m.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, m.heightPixels * 0.75f)
            lineTo(x, m.heightPixels * 0.35f)
        }
        return dispatch(GestureDescription.StrokeDescription(path, 0, 300))
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription): Boolean {
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val accepted = service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                ok.set(true)
                latch.countDown()
            }

            override fun onCancelled(g: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!accepted) return false
        latch.await(2, TimeUnit.SECONDS)
        return ok.get()
    }

    fun setText(n: AccessibilityNodeInfo, value: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun currentText(n: AccessibilityNodeInfo): String {
        n.refresh()
        return textOf(n)
    }

    /** Scrolls the largest visible scrollable container forward. Returns false if nothing scrolled. */
    fun scrollForward(all: List<AccessibilityNodeInfo> = snapshot()): Boolean {
        val best = all.filter { it.isScrollable && it.isVisibleToUser }.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height()
        } ?: return false
        return best.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    companion object {
        private const val MAX_NODES = 8000
    }
}
