package com.srisevamitra.assistant

import android.Manifest
import android.app.StatusBarManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val genders = listOf("Male", "Female")
    private val idTypes = listOf("Aadhaar", "Passport")

    private fun et(id: Int) = findViewById<EditText>(id)
    private fun sp(id: Int) = findViewById<Spinner>(id)
    private fun btn(id: Int, action: () -> Unit) = findViewById<Button>(id).setOnClickListener { action() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = getString(R.string.app_name)
        prefs = Prefs(this)

        for (id in listOf(R.id.p1Gender, R.id.p2Gender)) {
            sp(id).adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, genders)
        }
        for (id in listOf(R.id.p1IdType, R.id.p2IdType)) {
            sp(id).adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, idTypes)
        }
        populate(prefs.load())

        btn(R.id.btnOverlay) { openOverlaySettings() }
        btn(R.id.btnAccessibility) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(R.id.btnAutoEnable) { autoEnableAccessibility() }
        btn(R.id.btnAutofill) { openAutofillSettings() }
        btn(R.id.btnTile) { addTile() }
        btn(R.id.btnBubbleStart) { startBubble() }
        btn(R.id.btnBubbleStop) { stopBubble() }
        btn(R.id.btnSave) {
            val cfg = save()
            Toast.makeText(this, Prefs.validate(cfg) ?: "Saved", Toast.LENGTH_LONG).show()
        }
        btn(R.id.btnArm) { toggleArm() }
        btn(R.id.btnCopyReport) { copyReport() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun save(): Config {
        val cfg = readForm()
        prefs.save(cfg)
        prefs.targetPackage = et(R.id.etTarget).text.toString().trim()
        return cfg
    }

    // ------------------------------------------------------------------ setup actions

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun openAutofillSettings() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(this, "Autofill settings are not available on this phone", Toast.LENGTH_LONG).show()
        }
    }

    private fun addTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            val sbm = getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                ComponentName(this, SevaTileService::class.java),
                getString(R.string.tile_label),
                Icon.createWithResource(this, R.drawable.ic_tile),
                ContextCompat.getMainExecutor(this)
            ) { }
        } else {
            Toast.makeText(
                this,
                "Pull down Quick Settings, tap the pencil/Edit icon and drag 'Seva Fill' into the panel",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        save()
        ContextCompat.startForegroundService(this, Intent(this, FloatingBubbleService::class.java))
        FloatingBubbleService.running = true
        refreshStatus()
    }

    private fun stopBubble() {
        startService(Intent(this, FloatingBubbleService::class.java).setAction(FloatingBubbleService.ACTION_STOP))
        FloatingBubbleService.running = false
        refreshStatus()
    }

    /** Works only if WRITE_SECURE_SETTINGS was granted with adb (see README). */
    private fun autoEnableAccessibility() {
        val me = ComponentName(this, BookingAutomationService::class.java).flattenToString()
        try {
            val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!cur.split(':').contains(me)) {
                Settings.Secure.putString(
                    contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                    if (cur.isEmpty()) me else "$cur:$me"
                )
            }
            Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            Toast.makeText(this, "Accessibility turned ON", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(
                this,
                "Not allowed yet. On a PC run: adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS",
                Toast.LENGTH_LONG
            ).show()
        }
        refreshStatus()
    }

    private fun copyReport() {
        val f = getFileStreamPath(StateMachine.REPORT_FILE)
        if (!f.exists()) {
            Toast.makeText(this, "No scan report yet. Use 'Scan form (15 s)' on the floating button.", Toast.LENGTH_LONG).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Sri Seva Mitra scan report", f.readText()))
        Toast.makeText(this, "Report copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ arm / status

    private fun toggleArm() {
        if (prefs.armed) {
            prefs.armed = false
            BookingAutomationService.instance?.cancel()
            Toast.makeText(this, "Automation stopped", Toast.LENGTH_SHORT).show()
            refreshStatus()
            return
        }
        val cfg = save()
        val problem = Prefs.validate(cfg)
        if (problem != null) {
            Toast.makeText(this, problem, Toast.LENGTH_LONG).show()
            return
        }
        if (!serviceEnabled()) {
            Toast.makeText(this, "Turn ON 'Sri Seva Mitra' in Accessibility settings first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        prefs.lastStatus = "Armed - open the TTD booking page"
        prefs.armed = true
        Toast.makeText(this, "Armed. Now open the TTD booking page.", Toast.LENGTH_LONG).show()
        refreshStatus()
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, BookingAutomationService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), ignoreCase = true) ||
                it.equals(cn.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun refreshStatus() {
        findViewById<Button>(R.id.btnArm).text =
            if (prefs.armed) "Stop / disarm automation" else "Start automation (arm)"
        val lines = listOf(
            "Display over other apps: " + if (Settings.canDrawOverlays(this)) "ON" else "OFF",
            "Accessibility: " + if (serviceEnabled()) "ON" else "OFF (set up step 2)",
            "Floating button: " + if (FloatingBubbleService.running) "running" else "off",
            "Armed: " + if (prefs.armed) "YES" else "no",
            "Last status: " + prefs.lastStatus.ifEmpty { "-" }
        )
        findViewById<TextView>(R.id.tvStatus).text = lines.joinToString("\n")
    }

    // ------------------------------------------------------------------ form <-> config

    private fun populate(c: Config) {
        et(R.id.etSeva).setText(c.seva)
        et(R.id.etMonth).setText(c.month)
        et(R.id.etDay).setText(if (c.day > 0) c.day.toString() else "")
        et(R.id.etPersons).setText(c.persons.toString())
        et(R.id.etTarget).setText(prefs.targetPackage)
        et(R.id.etEmail).setText(c.email)
        et(R.id.etCity).setText(c.city)
        et(R.id.etState).setText(c.state)
        et(R.id.etCountry).setText(c.country)
        et(R.id.etPincode).setText(c.pincode)
        fillPilgrim(c.pilgrims[0], R.id.p1Name, R.id.p1Age, R.id.p1Gender, R.id.p1IdType, R.id.p1IdNumber)
        fillPilgrim(c.pilgrims[1], R.id.p2Name, R.id.p2Age, R.id.p2Gender, R.id.p2IdType, R.id.p2IdNumber)
        findViewById<CheckBox>(R.id.cbAutoConfirm).isChecked = c.autoConfirm
        et(R.id.etWait).setText(c.waitSeconds.toString())
    }

    private fun fillPilgrim(p: Pilgrim, name: Int, age: Int, gender: Int, idType: Int, idNum: Int) {
        et(name).setText(p.name)
        et(age).setText(p.age)
        sp(gender).setSelection(genders.indexOf(p.gender).coerceAtLeast(0))
        sp(idType).setSelection(idTypes.indexOf(p.idType).coerceAtLeast(0))
        et(idNum).setText(p.idNumber)
    }

    private fun readPilgrim(name: Int, age: Int, gender: Int, idType: Int, idNum: Int) = Pilgrim(
        name = et(name).text.toString().trim(),
        age = et(age).text.toString().trim(),
        gender = sp(gender).selectedItem.toString(),
        idType = sp(idType).selectedItem.toString(),
        idNumber = et(idNum).text.toString().trim()
    )

    private fun readForm(): Config = Config(
        seva = et(R.id.etSeva).text.toString().trim(),
        month = et(R.id.etMonth).text.toString().trim(),
        day = et(R.id.etDay).text.toString().trim().toIntOrNull() ?: 0,
        persons = et(R.id.etPersons).text.toString().trim().toIntOrNull() ?: 1,
        email = et(R.id.etEmail).text.toString().trim(),
        city = et(R.id.etCity).text.toString().trim(),
        state = et(R.id.etState).text.toString().trim(),
        country = et(R.id.etCountry).text.toString().trim().ifEmpty { "India" },
        pincode = et(R.id.etPincode).text.toString().trim(),
        pilgrims = listOf(
            readPilgrim(R.id.p1Name, R.id.p1Age, R.id.p1Gender, R.id.p1IdType, R.id.p1IdNumber),
            readPilgrim(R.id.p2Name, R.id.p2Age, R.id.p2Gender, R.id.p2IdType, R.id.p2IdNumber)
        ),
        autoConfirm = findViewById<CheckBox>(R.id.cbAutoConfirm).isChecked,
        waitSeconds = et(R.id.etWait).text.toString().trim().toIntOrNull() ?: 300
    )
}
