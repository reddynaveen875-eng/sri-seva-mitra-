package com.srisevamitra.assistant

import android.content.Context
import android.content.SharedPreferences

data class Pilgrim(
    val name: String,
    val age: String,
    val gender: String,
    val idType: String,
    val idNumber: String
) {
    fun isComplete(): Boolean = name.isNotBlank() && age.isNotBlank() && idNumber.isNotBlank()
}

data class Config(
    val seva: String,
    val month: String,
    val day: Int,
    val persons: Int,
    val email: String,
    val city: String,
    val state: String,
    val country: String,
    val pincode: String,
    val pilgrims: List<Pilgrim>,
    val autoConfirm: Boolean,
    val waitSeconds: Int
) {
    /** Only the pilgrims that will actually be booked (1 or 2). */
    val activePilgrims: List<Pilgrim> get() = pilgrims.take(persons)
}

/** Thin wrapper around SharedPreferences. Written by MainActivity, read by the service. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    var armed: Boolean
        get() = sp.getBoolean("armed", false)
        set(v) { sp.edit().putBoolean("armed", v).apply() }

    /** Package of the browser/app to drive. Empty = any app. */
    var targetPackage: String
        get() = sp.getString("target_pkg", "com.android.chrome") ?: "com.android.chrome"
        set(v) { sp.edit().putString("target_pkg", v).apply() }

    var lastStatus: String
        get() = sp.getString("last_status", "") ?: ""
        set(v) { sp.edit().putString("last_status", v).apply() }

    fun load(): Config {
        fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
        fun pilgrim(n: Int) = Pilgrim(
            name = s("p${n}_name"),
            age = s("p${n}_age"),
            gender = s("p${n}_gender", "Male"),
            idType = s("p${n}_idtype", "Aadhaar"),
            idNumber = s("p${n}_idnumber")
        )
        return Config(
            seva = s("seva"),
            month = s("month"),
            day = sp.getInt("day", 0),
            persons = sp.getInt("persons", 1),
            email = s("email"),
            city = s("city"),
            state = s("state"),
            country = s("country", "India"),
            pincode = s("pincode"),
            pilgrims = listOf(pilgrim(1), pilgrim(2)),
            autoConfirm = sp.getBoolean("auto_confirm", false),
            waitSeconds = sp.getInt("wait_seconds", 300)
        )
    }

    fun save(c: Config) {
        val e = sp.edit()
        e.putString("seva", c.seva)
        e.putString("month", c.month)
        e.putInt("day", c.day)
        e.putInt("persons", c.persons)
        e.putString("email", c.email)
        e.putString("city", c.city)
        e.putString("state", c.state)
        e.putString("country", c.country)
        e.putString("pincode", c.pincode)
        c.pilgrims.forEachIndexed { i, p ->
            val n = i + 1
            e.putString("p${n}_name", p.name)
            e.putString("p${n}_age", p.age)
            e.putString("p${n}_gender", p.gender)
            e.putString("p${n}_idtype", p.idType)
            e.putString("p${n}_idnumber", p.idNumber)
        }
        e.putBoolean("auto_confirm", c.autoConfirm)
        e.putInt("wait_seconds", c.waitSeconds)
        e.apply()
    }

    companion object {
        private const val NAME = "ttd_booking_prefs"

        /** Returns a human-readable problem, or null when the config is usable. */
        fun validate(c: Config, needCalendar: Boolean = true): String? {
            if (needCalendar) {
                if (c.month.isBlank()) return "Calendar month is empty (e.g. December 2026)"
                if (c.day !in 1..31) return "Day must be between 1 and 31"
                if (c.waitSeconds < 1) return "Wait seconds must be at least 1"
            }
            if (c.persons !in 1..2) return "Number of persons must be 1 or 2"
            c.activePilgrims.forEachIndexed { i, p ->
                if (!p.isComplete()) return "Pilgrim ${i + 1}: name, age and ID number are required"
            }
            return null
        }
    }
}
